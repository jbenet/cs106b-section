/* Instance variables */

   long id;       /* id linking this thread to the platform-specific data */
